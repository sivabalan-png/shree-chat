// Register Function
function register() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  firebase.auth().createUserWithEmailAndPassword(email, password)
    .then(() => {
      document.getElementById("message").innerText = "Registered Successfully!";
    })
    .catch(error => {
      document.getElementById("message").innerText = error.message;
    });
}

// Login Function
function login() {
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  firebase.auth().signInWithEmailAndPassword(email, password)
    .then(() => {
      window.location.href = "chat.html";
    })
    .catch(error => {
      document.getElementById("message").innerText = error.message;
    });
}