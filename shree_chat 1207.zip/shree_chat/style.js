// style.js

// Chat box style
const chatBox = document.getElementById("chatBox");
chatBox.style.padding = "10px";
chatBox.style.backgroundColor = "#f9f9f9";
chatBox.style.borderRadius = "5px";
chatBox.style.boxShadow = "0 0 5px rgba(0,0,0,0.2)";
chatBox.style.fontFamily = "Arial, sans-serif";
chatBox.style.fontSize = "14px";
chatBox.style.color = "#333";

// Input field style
const msgInput = document.getElementById("msg");
msgInput.style.width = "70%";
msgInput.style.padding = "10px";
msgInput.style.border = "1px solid #ccc";
msgInput.style.borderRadius = "5px";
msgInput.style.marginRight = "10px";
msgInput.style.fontSize = "14px";

// Button style
const buttons = document.querySelectorAll("button");
buttons.forEach(btn => {
  btn.style.padding = "10px 15px";
  btn.style.border = "none";
  btn.style.borderRadius = "5px";
  btn.style.backgroundColor = "#007bff";
  btn.style.color = "#fff";
  btn.style.cursor = "pointer";
  btn.style.fontSize = "14px";
  btn.style.transition = "background-color 0.3s";
  
  btn.addEventListener("mouseover", () => {
    btn.style.backgroundColor = "#0056b3";
  });
  btn.addEventListener("mouseout", () => {
    btn.style.backgroundColor = "#007bff";
  });
});

// Messages style
const messages = chatBox.getElementsByTagName("p");
for (let msg of messages) {
  msg.style.margin = "5px 0";
  msg.style.padding = "5px 8px";
  msg.style.borderRadius = "5px";
}